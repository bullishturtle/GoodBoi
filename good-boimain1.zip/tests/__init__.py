"""Tests for GoodBoy.AI."""
