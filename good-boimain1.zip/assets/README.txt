Place your branding images here for the GoodBoy.AI desktop console.

Expected filenames (optional but supported):

- goodboy_icon.ico      -> window icon (use the GoodBoy.AI dog logo rendered as .ico)
- goodboy_logo.png      -> header logo shown in the Jarvis-style console bar

You can export the logo and blueprint images you designed and save them with these names.
The application will automatically pick them up on next launch if they exist.
