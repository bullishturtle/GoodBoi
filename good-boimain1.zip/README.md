# GoodBoy.AI

**Your Intelligent AI Assistant** - A self-aware, self-learning personal AI assistant with a unified brain architecture.

## Overview

GoodBoy.AI is a sophisticated multi-agent AI system featuring:

- **Council Architecture**: 6 specialized agents working together (Batman, Alfred, Jarvis, DaVinci, Architect, Analyst)
- **Self-Learning**: Continuous improvement through interaction patterns
- **Memory Management**: Persistent conversation history and semantic retrieval
- **Local-First**: Runs entirely on your machine with local GGUF models
- **Desktop & Web**: Tkinter desktop UI + Gradio web dashboard + REST API

## Quick Start

### Windows (Recommended)

\`\`\`bash
# 1. Install dependencies
INSTALL.bat

# 2. Launch the application
GoodBoy_launcher.bat
\`\`\`

### Manual Setup

\`\`\`bash
# Create virtual environment
python -m venv venv
.\venv\Scripts\activate  # Windows
source venv/bin/activate  # Linux/Mac

# Install dependencies
pip install -r requirements.txt

# Start the server
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000

# In another terminal, start the UI
python GoodBoy_ui.py
\`\`\`

## Architecture

\`\`\`
                    YOU (Mayor)
                        |
                  UNIFIED BRAIN
            (Chain-of-Thought Reasoning)
                        |
              CENTRAL HALL (Council)
    +-------+-------+-------+-------+-------+-------+
    |Batman |Alfred |Jarvis |DaVinci|Architect|Analyst|
    |Security|Schedule|Control|Creative|Builder |Data  |
    +-------+-------+-------+-------+-------+-------+
                        |
    +-------------------+-------------------+
    |                   |                   |
MEMORY GARDENS    DATA TOWERS    EVOLUTION GARDENS
\`\`\`

## Council Agents

| Agent | Role | Specialization |
|-------|------|----------------|
| **Batman** | Strategy & Security | Threat assessment, security protocols |
| **Alfred** | Scheduling & Emails | Calendar, communications, logistics |
| **Jarvis** | System Control | Core operations, resource management |
| **DaVinci** | Creativity & Design | Ideas, UI/UX, innovation |
| **Architect** | Builder & Code | Development, architecture |
| **Analyst** | Data & Insights | Analysis, metrics, patterns |

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/` | GET | Health check and status |
| `/chat` | POST | Send message to Bathy |
| `/agents` | GET | List available agents |
| `/memory/search` | GET | Search long-term memory |
| `/teach` | POST | Teach Bathy new knowledge |
| `/tools/exec` | POST | Execute a registered tool |

## Configuration

Edit `data/GoodBoy_config.json`:

\`\`\`json
{
  "engine": "local",
  "model_path": "models/your-model.gguf",
  "safety_mode": "interactive",
  "max_tokens": 512
}
\`\`\`

## Safety Modes

- **read-only**: No file modifications
- **interactive**: Requires consent for destructive actions
- **autonomous**: Full automation (use carefully)

## Documentation

- [Architecture Guide](docs/architecture.md)
- [Quick Start Guide](docs/quickstart.md)
- [Build Guide](BUILD_GUIDE.md)
- [Changelog](CHANGELOG.md)

## License

See [LICENSE.txt](LICENSE.txt) for details.

---

Built with care for Lando by the GoodBoy.AI team.
