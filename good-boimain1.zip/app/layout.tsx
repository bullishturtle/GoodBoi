import type React from "react"
import type { Metadata, Viewport } from "next"
import { Geist, Geist_Mono } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import "./globals.css"

const geistSans = Geist({
  subsets: ["latin"],
  variable: "--font-geist-sans",
})
const geistMono = Geist_Mono({
  subsets: ["latin"],
  variable: "--font-geist-mono",
})

export const metadata: Metadata = {
  title: "GoodBoy.AI - Your Intelligent AI Assistant",
  description:
    "GoodBoy.AI is a self-aware, self-learning personal AI assistant with a unified brain architecture. Accelerate your workflow with intelligent AI agents.",
  keywords: ["AI assistant", "GoodBoy.AI", "artificial intelligence", "productivity", "automation", "coding assistant"],
  authors: [{ name: "GoodBoy.AI Team" }],
  creator: "GoodBoy.AI",
  publisher: "GoodBoy.AI",
  icons: {
    icon: "/icon.svg",
    shortcut: "/icon.svg",
    apple: "/icon.svg",
  },
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://goodboy.ai",
    siteName: "GoodBoy.AI",
    title: "GoodBoy.AI - Your Intelligent AI Assistant",
    description: "Accelerate your workflow with intelligent AI agents that write, review, and optimize your code.",
    images: [
      {
        url: "/images/dashboard-preview.png",
        width: 1200,
        height: 630,
        alt: "GoodBoy.AI Dashboard Preview",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "GoodBoy.AI - Your Intelligent AI Assistant",
    description: "Accelerate your workflow with intelligent AI agents.",
    images: ["/images/dashboard-preview.png"],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
    generator: 'v0.app'
}

export const viewport: Viewport = {
  themeColor: "#0f1211",
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${geistSans.variable} ${geistMono.variable}`}>
      <body className="font-sans antialiased">
        {children}
        <Analytics />
      </body>
    </html>
  )
}
