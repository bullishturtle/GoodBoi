# GoodBoy.AI FastAPI app package
