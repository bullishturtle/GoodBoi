from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Dict, Any

from ..models_backend import ModelBackend


@dataclass
class AgentProposal:
    agent: str
    role: str
    proposal: str


@dataclass
class AgentConfig:
    name: str
    role: str
    description: str
    style: str


@dataclass
class ToolResult:
    success: bool
    output: Any
    error: Optional[str] = None


class BaseAgent:
    """Base class for all GoodBoy.AI council agents."""
    
    def __init__(self, cfg: AgentConfig = None, name: str = None, role: str = None, 
                 description: str = None, system_prompt: str = None) -> None:
        # Support both old AgentConfig style and new keyword style
        if cfg:
            self.cfg = cfg
            self._system_prompt = None
        else:
            self.cfg = AgentConfig(
                name=name or "agent",
                role=role or "Agent",
                description=description or "",
                style=""
            )
            self._system_prompt = system_prompt
        
        self.backend = ModelBackend.instance()

    @property
    def name(self) -> str:
        return self.cfg.name

    @property
    def role(self) -> str:
        return self.cfg.role

    def build_prompt(self, message: str) -> str:
        """Default prompt template. Subclasses can override for more control."""
        if self._system_prompt:
            return (
                f"{self._system_prompt}\n\n"
                f"User request: {message}\n"
                f"Your response:"
            )
        return (
            "You are {role} in GoodBoy.AI City, serving Lando (the owner). "
            "You speak as a refined, loyal canine advisor: calm, clear, and focused entirely on Lando's best outcome. "
            "Stay in your lane: {desc}. Be concrete and actionable. If information is missing, say exactly what you need, then suggest next steps.\n\n"
            "Owner's request: {msg}\n"
            "Advisor ({name}) response:"
        ).format(
            role=self.cfg.role,
            desc=self.cfg.description,
            msg=message,
            name=self.cfg.name,
        )

    def propose(self, message: str, max_tokens: Optional[int] = None) -> AgentProposal:
        """Generate a proposal for the given message."""
        prompt = self.build_prompt(message)
        text = self.backend.generate(prompt, max_tokens=max_tokens)
        return AgentProposal(agent=self.cfg.name, role=self.cfg.role, proposal=text)

    def think(self, message: str, context: Optional[str] = None) -> str:
        """Use LLM to think about a message with optional context."""
        prompt = self.build_prompt(message)
        if context:
            prompt = f"{prompt}\n\nContext: {context}"
        return self.backend.generate(prompt, max_tokens=512)

    def use_tool(self, tool_name: str, **kwargs) -> ToolResult:
        """Execute a tool and return the result."""
        from ..tools import execute_tool
        try:
            result = execute_tool(tool_name, kwargs)
            return ToolResult(success=result.ok, output=result.data, error=None if result.ok else result.detail)
        except Exception as e:
            return ToolResult(success=False, output={}, error=str(e))

    def _format_response(self, response: str) -> str:
        """Format the agent's response consistently."""
        return response.strip()

    def get_status(self) -> Dict[str, Any]:
        """Get agent status information."""
        return {
            "name": self.name,
            "role": self.role,
            "description": self.cfg.description,
            "active": True,
        }
