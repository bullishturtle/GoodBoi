"""Agent definitions for GoodBoy.AI City.

Bathy (president) coordinates multiple advisor agents (writer, ops, research, security, etc.).
"""

from .base import BaseAgent, AgentConfig, AgentProposal
from .batman import BatmanAgent
from .alfred import AlfredAgent
from .jarvis import JarvisAgent
from .davinci import DaVinciAgent
from .architect import ArchitectAgent
from .analyst import AnalystAgent

__all__ = [
    "BaseAgent",
    "AgentConfig", 
    "AgentProposal",
    "BatmanAgent",
    "AlfredAgent",
    "JarvisAgent",
    "DaVinciAgent",
    "ArchitectAgent",
    "AnalystAgent",
]
